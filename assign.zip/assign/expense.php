<?php
require 'config.php';

// Retrieve expenses from session
function getExpensesFromSession() {
  return isset($_SESSION['expenses']) ? $_SESSION['expenses'] : [];
}

// Save expenses to session
function saveExpensesToSession($expenses) {
  $_SESSION['expenses'] = $expenses;
}

// Array to store expenses
$expenses = getExpensesFromSession();

// Add new expense to the expenses array
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $date = $_POST['date'];
  $amount = $_POST['amount'];
  $category = $_POST['category'];
  $description = $_POST['description'];

  // Create an array for the new expense
  $newExpense = array(
    'date' => $date,
    'amount' => $amount,
    'category' => $category,
    'description' => $description
  );

  // Add the new expense to the expenses array
  $expenses[] = $newExpense;

  // Save the updated expenses array to session
  saveExpensesToSession($expenses);

  // Redirect to the report page
  header('Location: expense.php');
  exit();
}

?>

<!DOCTYPE html>
<html>
<head>
  <title>Expense Tracker</title>
  <!-- <link rel="stylesheet" href="styles.css"> -->
</head>
<body>

<h1 style="color: darkgreen;">Expense Tracker</h1>

<form id="expenseForm" method="POST">
  <label for="date" style="color: darkgreen;">&nbsp;Date:</label>
  <br>
  <input type="date" id="date" name="date" required><br>

  <label for="amount" style="color: darkgreen;">&nbsp;Amount:</label>
  <br>
  <input type="number" id="amount" name="amount" required><br>

  <label for="category" style="color: darkgreen;">&nbsp;Category:</label>
  <br>
  <select id="category" name="category" required>
    <option value="food">Food</option>
    <option value="transportation">Transportation</option>
    <option value="housing">Housing</option>
    <option value="entertainment">Entertainment</option>
    <option value="other">Other</option>
  </select><br>

  <label for="description" style="color: darkgreen;">&nbsp;Description:</label>
  <br>
  <input type="text" id="description" name="description" required><br>

  <input type="submit" class="btn" value="Add Expense">
</form>
<label for="searching" style="color: darkgreen;">&nbsp;&nbsp;&nbsp;&nbsp;Search:</label>
<br>
<input type="text" class="text" id="search" placeholder="Search by category" onkeyup="searchExpense()">

<!-- <table id="expenseTable">
  <thead>
    <tr>
      <th>Date</th>
      <th>Amount</th>
      <th>Category</th>
      <th>Description</th>
    </tr>
  </thead>
  <tbody id="expenseTableBody">
    <?php foreach ($expenses as $expense): ?>
    <tr>
      <td><?php echo $expense['date']; ?></td>
      <td><?php echo $expense['amount']; ?></td>
      <td><?php echo $expense['category']; ?></td>
      <td><?php echo $expense['description']; ?></td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table> -->

<script>
  // Function to search expenses by category
  function searchExpense() {
    var input = document.getElementById('search').value.toLowerCase();
    var filteredExpenses = <?php echo json_encode($expenses); ?>.filter(function(expense) {
      return expense.category.toLowerCase().indexOf(input) > -1;
    });

    // Clear the expense table
    var tbody = document.getElementById('expenseTableBody');
    tbody.innerHTML = '';

    // Add filtered expenses to the table
    filteredExpenses.forEach(function(expense) {
      var row = tbody.insertRow();

      var dateCell = row.insertCell(0);
      dateCell.innerHTML = expense.date;

      var amountCell = row.insertCell(1);
      amountCell.innerHTML = expense.amount;

      var categoryCell = row.insertCell(2);
      categoryCell.innerHTML = expense.category;

      var descriptionCell = row.insertCell(3);
      descriptionCell.innerHTML = expense.description;
    });
  }

</script>

<div class="buttons">
     <a href="home.php"><button class="btn">Back</button></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     <a href="expense.php"><button class="btn" id="saveButton">Save</button></a>

</div>

 <style>

body {
  font-family: Arial, sans-serif;
  background-color: #f2f2f2;
  margin: 0;
  padding: 20px;
  background-color:rgb(15, 15, 15);
  
}

h1 {
  text-align: center;
}

form {
  background-color: #fff;
  padding: 25px;
  margin-bottom: 26px;
  border-radius: 10px;
  background-color: black;

}

form label {
  font-weight: bold;
}
form [type = "date"]{
  width: 75%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  margin: 10px 3px;

}
form [type = "text"]{
  width: 75%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  margin: 10px 3px;

}
.text{
  width: 73.5%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  margin: 10px 21px;
}
form input[type="number"]
{
  width: 75%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  margin: 10px 3px;

}
form select {
  width: 76.5%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  margin: 10px 3px;

}

form button[type="submit"] {
  background-color: #4CAF50;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

h2 {
  text-align: center;
}

ul {
  list-style-type: none;
  padding: 0;
  margin: 0;
}

li {
  background-color: #fff;
  padding: 20px;
  margin-bottom: 10px;
  border-radius: 5px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}
.buttons {
    margin-top: 38px;
    font-size: 8px;
}

.btn {
  
    background-color: #4CAF50;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.btn:hover {
    background-color: black;
    color: yellow;
}
.btn-sm{
    font-size: 12px;
    padding: 8px 8px;
    margin: 10px 0;

}



  </style>
</body>
</html>
