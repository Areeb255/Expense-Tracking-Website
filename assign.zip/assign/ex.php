<!DOCTYPE html>
<html>
<head>
    <title>Survey Form</title>
    <script>
        function validateForm() {
            var password1 = document.getElementById("password1").value;
            var password2 = document.getElementById("password2").value;

            if (password1.length < 8) {
                alert("Password should be at least 8 characters long");
                return false;
            }

            if (password1 !== password2) {
                alert("Passwords do not match");
                return false;
            }
        }
    </script>
</head>
<body>
    <h2>Survey Form</h2>
    <form action="second.php" method="post" onsubmit="return validateForm()">
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" required><br><br>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required><br><br>

        <label for="password1">Password:</label>
        <input type="password" name="password1" id="password1" required><br><br>

        <label for="password2">Confirm Password:</label>
        <input type="password" name="password2" id="password2" required><br><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
