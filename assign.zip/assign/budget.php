<!DOCTYPE html>
<html>
<head>
    <title>Budgeting Tool</title>
    <!-- <link rel="stylesheet" type="text/css" href="styles.css"> -->
</head>
<body>

    <h1>Budgeting Tool</h1>
    <form id="expenseForm">
    <label for="budgetAmount">Amount:</label>
    <input type="number" id="budgetAmount" required>
<br>
    <label for="budgetCategory">Category:</label>
    <select id="budgetCategory" required onchange="handleCategoryChange()">
      <option value="">Select a budget category</option>
      <option value="Businessman">Businessman</option>
      <option value="Employee">Employee</option>
      <option value="Labour">Labour</option>
      <option value="Mechanic">Mechanic</option>
      <option value="Other">Other</option>
    </select>
    <br>
    <div id="otherCategoryContainer" style="display: none;">
      <label for="otherCategory">Other Category:</label>
      <input type="text" id="otherCategory">
    </div>
    <br>
    <button type="submit">Add Budget</button>
  </form>

  <h2>Budgets:</h2>
  <ul id="budgetList"></ul>

  
    <script>
      // Function to save budget to local storage
function saveExpense(budgetamount, budgetcategory) {
  let budget = localStorage.getItem('budget');

  if (budget) {
    budget = JSON.parse(budget);
  } else {
    budget = [];
  }

  budget.push({ budgetamount: budgetamount, budgetcategory: budgetcategory });

  localStorage.setItem('budget', JSON.stringify(budget));
}

// Function to load budget from local storage
function loadExpenses() {
  let budget = localStorage.getItem('budget');

  if (budget) {
    budget = JSON.parse(budget);

    const budgetList = document.getElementById('budgetList');
    budgetList.innerHTML = '';

    budget.forEach(function(expense) {
      const budgetItem = document.createElement('li');
      budgetItem.innerHTML = `
        <img src="icon.png" alt="Expense Category" width="100px" height="100px">
        <div>
          <p>Amount: $${expense.budgetamount}</p>
          <p>Category: ${expense.budgetcategory}</p>
        </div>
      `;

      budgetList.appendChild(budgetItem);
    });
  }
}

// Event listener for submitting the expense form
document.getElementById('expenseForm').addEventListener('submit', function(event) {
  event.preventDefault();

  // Get the values from the form
  const budgetamount = document.getElementById('budgetAmount').value;
  const budgetcategory = document.getElementById('budgetCategory').value;

  // If the selected category is "Other", get the value from the otherCategory input field
  if (budgetcategory === 'Other') {
    const otherCategory = document.getElementById('otherCategory').value.trim();
    if (otherCategory !== '') {
      saveExpense(budgetamount, otherCategory);
    }
  } else {
    // Save the expense
    saveExpense(budgetamount, budgetcategory);
  }

  // Load all budget
  loadExpenses();

  // Clear the form fields
  document.getElementById('budgetAmount').value = '';
  document.getElementById('budgetCategory').value = '';
  document.getElementById('otherCategory').value = '';
  handleCategoryChange(); // Hide the otherCategory input field
});

// Function to handle category change event
function handleCategoryChange() {
  const budgetCategory = document.getElementById('budgetCategory');
  const otherCategoryContainer = document.getElementById('otherCategoryContainer');
  if (budgetCategory.value === 'Other') {
    otherCategoryContainer.style.display = 'block';
  } else {
    otherCategoryContainer.style.display = 'none';
  }
}

// Load all budget on page load
window.addEventListener('load', function() {
  loadExpenses();
});
    </script>
    <div class="buttons">
     <a href="budget.php"><button class="btn" id="saveButton">Save</button></a>
     <a href="home.php"><button class="btn">Back</button></a>
</div>

  <style>
 
 body {
  font-family: Arial, sans-serif;
  background-color: #f2f2f2;
  margin: 0;
  padding: 20px;
}

h1 {
  text-align: center;
}

form {
  background-color: #fff;
  padding: 20px;
  margin-bottom: 20px;
  border-radius: 5px;
}

form label {
  font-weight: bold;
}

form input[type="number"],
form select,
form input[type="text"] {
  width: 95%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  margin: 10px 3px;
}

form button[type="submit"] {
  background-color: #4CAF50;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

h2 {
  text-align: center;
}

ul {
  list-style-type: none;
  padding: 0;
  margin: 0;
}

li {
  background-color: #fff;
  padding: 20px;
  margin-bottom: 10px;
  border-radius: 5px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.buttons {
    margin-top: 38px;
    font-size: 8px;
}

.btn {
    padding: 7px 14px;
    border-radius: 22px;
    color: white;
    background-color: dodgerblue;
    font-weight: bold;
    font-size: 2em;
    margin: 0 3px;
    cursor: pointer;
}

.btn:hover {
    background-color: white;
    color: dodgerblue;
}

.btn-sm{
    font-size: 12px;
    padding: 8px 8px;
    margin: 10px 0;
}
  </style>
</body>
</html>
