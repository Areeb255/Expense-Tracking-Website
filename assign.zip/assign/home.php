<?php
require 'config.php';

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expense Tracker Website</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <div class="sidebar sidebargo">
            <nav>
                <ul>
                <li><a href="expense.php">My Expenses</li></a>
                    <li><a href="login2.php">My Budget</li></a>
                    <li><a href="login1.php">Track Expenses</li></a>
                    <li><a href="about.php">About Us</li></a>
                    <li><a href="contact.php">Contact Us</li></a>
                </ul>
            </nav>
        </div>
        <div class="main">
            <div class="hamburger">
                <img class="side" src="sidebar.png" alt="sidebr" width="23">
                <img class="close" src="close.jpg" alt="closebar" width="23">
            </div>
            <div class="infocontainer">
                <div class="devinfo">
                    <div class="hello">Expense Tracker System</div>
                    <div class="about">Welcome to our website</div>
                    <div class="aboutmore">Tracking your Expenses through our website!</div>
                </div>
                <div class="devpic">
                    <img src="expe.jpg" alt="expense pic">
                    

                </div> 
            
            </div>
        </div>
    </div>
    <script src="script.js">

    </script>

</body>

</html>