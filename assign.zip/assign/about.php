<?php
require 'config.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
</head>

  <style>
    body {
      font-family: Arial, sans-serif;
      background-color:rgb(15, 15, 15);
      margin: 0;
      padding: 20px;
    }

    h2 {
      text-align: center;
    }

    p {
      margin-bottom: 20px;
    }

    .container {
      max-width: 800px;
      margin: 0 auto;
      background-color: lightgrey;
      padding: 30px;
      border-radius: 5px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .logo {
      display: block;
      margin: 0 auto;
      width: 350px;
      height: 250px;
      object-fit: contain;
      border-radius: 20%;
    }
  </style>
<body>
  <div class="container">
    <h2>About Expense Tracking System</h2>
    <p>Welcome to Expense Tracking System, a powerful tool designed to help you manage and track your expenses with ease. Our platform is built to simplify your financial management by providing intuitive features and insightful analysis.</p>

    <p>With Expense Tracking System, you can effortlessly track your income and expenses, categorize transactions, set budgets, and gain valuable insights into your spending habits. Our goal is to empower individuals and businesses to make informed financial decisions and achieve their financial goals.</p>

    <p>Whether you're a professional seeking to manage your business expenses or an individual looking to track personal finances, Expense Tracking System offers a comprehensive solution to streamline your expense management process.</p>

    <p>Experience the convenience and efficiency of Expense Tracking System and take control of your finances today.</p>
    <video autoplay loop muted class="logo">
        <source src="etw.mp4" >
        this video does not support your browser.
    </video>
  </div>
</body>
</html>
