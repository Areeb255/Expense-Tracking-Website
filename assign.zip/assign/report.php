<?php
require 'config.php';

// session_start();

// Retrieve expenses from session
function getExpensesFromSession() {
  return isset($_SESSION['expenses']) ? $_SESSION['expenses'] : [];
}

// Delete an expense by index
function deleteExpenseByIndex($index) {
  $expenses = getExpensesFromSession();
  if (isset($expenses[$index])) {
    unset($expenses[$index]);
    $_SESSION['expenses'] = array_values($expenses);
  }
}

// Array to store expenses
$expenses = getExpensesFromSession();

// Check if the delete request is received
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deleteIndex'])) {
  $deleteIndex = $_POST['deleteIndex'];
  deleteExpenseByIndex($deleteIndex);
}

?>

<!DOCTYPE html>
<html>
<head>
  <title>Expense Report</title>
  <style>
    body {
      background-color:rgb(15, 15, 15);
    }

    table {
      border-collapse: collapse;
      width: 100%;
    }

    td {
      border: 2px solid black;
      padding: 20px;
      text-align: center;
      font-weight: bold;
      border-radius: 10px;
      font-size: 18px;
    }

    th {
      border: 2px solid black;
      padding: 20px;
      text-align: center;
      background-color: rgba(65, 15, 54, 0.821);
      color: rgb(152, 141, 46);
      font-weight: bold;
      border-radius: 5px;
      font-size: 20px;
    }

    tr:nth-child(even) {
      background-color: rgb(109, 71, 1);
      color: rgba(65, 15, 54, 0.821);
    }

    tr:nth-child(odd) {
      color: darkgreen;
    }

    #search {
      margin-bottom: 20px;
    }

    h1 {
      text-align: center;
    }

    .text {
      width: 73.5%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      margin: 10px 21px;
      font-weight: bold;
    }

    .txt {
      font-size: 20px;
      font-weight: bold;
    }

    .btn-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
    }

    .btn-delete,
    .btn-update,
    .btn-save,
    .btn-cancel {
      padding: 8px 15px;
      margin-top: 5px;
      border: none;
      cursor: pointer;
      border-radius: 5px;
      font-weight: bold;
    }

    .btn-delete {
      background-color: #ff0000;
      color: #fff;
    }

    .btn-update {
      background-color: #009900;
      color: #fff;
    }

    .btn-save {
      background-color: #0088cc;
      color: #fff;
    }

    .btn-cancel {
      background-color: #777777;
      color: #fff;
    }

    .input-field {
      width: 100%;
      padding: 5px;
      border: 1px solid #ccc;
      border-radius: 3px;
    }
  </style>
</head>
<body>
  <h1 style="color: darkgreen;">Expense Report</h1>

  <label for="searching" style="color: darkgreen;" class="txt">&nbsp;&nbsp;&nbsp;&nbsp;Search:</label>
  <br>
  <input type="text" class="text" id="search" placeholder="Search by category" onkeyup="searchExpense()">

  <table id="expenseTable">
    <thead>
      <tr>
        <th>Date</th>
        <th>Amount</th>
        <th>Category</th>
        <th>Description</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody id="expenseTableBody">
      <?php foreach ($expenses as $index => $expense): ?>
      <tr>
        <td><?php echo $expense['date']; ?></td>
        <td><?php echo $expense['amount']; ?></td>
        <td><?php echo $expense['category']; ?></td>
        <td><?php echo $expense['description']; ?></td>
        <td class="btn-container">
          <form method="POST" style="display:inline;">
            <input type="hidden" name="deleteIndex" value="<?php echo $index; ?>">
            <button class="btn-delete" onclick="return confirm('Are you sure you want to delete this expense?')">Delete</button>
          </form>
          <button class="btn-update" onclick="editExpense(this, <?php echo $index; ?>)">Update</button>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <script>
    // Function to search expenses by category
    function searchExpense() {
      var input = document.getElementById('search').value.toLowerCase();
      var rows = document.getElementById('expenseTableBody').getElementsByTagName('tr');

      for (var i = 0; i < rows.length; i++) {
        var categoryCell = rows[i].getElementsByTagName('td')[2];
        var category = categoryCell.textContent.toLowerCase();

        if (category.indexOf(input) > -1) {
          rows[i].style.display = '';
        } else {
          rows[i].style.display = 'none';
        }
      }
    }

    // Function to edit/update an expense
    function editExpense(button, index) {
      var row = button.parentNode.parentNode;
      var cells = row.getElementsByTagName('td');
      var date = cells[0].textContent;
      var amount = cells[1].textContent;
      var category = cells[2].textContent;
      var description = cells[3].textContent;

      // Replace the row content with input fields for editing
      cells[0].innerHTML = '<input type="text" class="input-field" value="' + date + '">';
      cells[1].innerHTML = '<input type="text" class="input-field" value="' + amount + '">';
      cells[2].innerHTML = '<input type="text" class="input-field" value="' + category + '">';
      cells[3].innerHTML = '<input type="text" class="input-field" value="' + description + '">';

      // Update the actions column with Save and Cancel buttons
      var actionsCell = cells[4];
      actionsCell.innerHTML = '<button class="btn-save" onclick="saveExpense(this, ' + index + ')">Save</button> <button class="btn-cancel" onclick="cancelEdit(this, \'' + date + '\', \'' + amount + '\', \'' + category + '\', \'' + description + '\')">Cancel</button>';
    }

    // Function to save the edited expense
    function saveExpense(button, index) {
      var row = button.parentNode.parentNode;
      var cells = row.getElementsByTagName('td');
      var updatedDate = cells[0].getElementsByTagName('input')[0].value;
      var updatedAmount = cells[1].getElementsByTagName('input')[0].value;
      var updatedCategory = cells[2].getElementsByTagName('input')[0].value;
      var updatedDescription = cells[3].getElementsByTagName('input')[0].value;

      // Perform any necessary validation before saving the expense

      // Update the expense data in the table
      cells[0].textContent = updatedDate;
      cells[1].textContent = updatedAmount;
      cells[2].textContent = updatedCategory;
      cells[3].textContent = updatedDescription;

      // Update the actions column with Delete and Update buttons
      cells[4].innerHTML = '<form method="POST" style="display:inline;"><input type="hidden" name="deleteIndex" value="' + index + '"><button class="btn-delete" onclick="return confirm(\'Are you sure you want to delete this expense?\')">Delete</button></form> <button class="btn-update" onclick="editExpense(this, ' + index + ')">Update</button>';
    }

    // Function to cancel editing and restore the original expense data
    function cancelEdit(button,index) {
      var row = button.parentNode.parentNode;
      var cells = row.getElementsByTagName('td');
      var updatedDate = cells[0].getElementsByTagName('input')[0].value;
      var updatedAmount = cells[1].getElementsByTagName('input')[0].value;
      var updatedCategory = cells[2].getElementsByTagName('input')[0].value;
      var updatedDescription = cells[3].getElementsByTagName('input')[0].value;

      // Restore the original expense data
      cells[0].textContent = updatedDate;
      cells[1].textContent = updatedAmount;
      cells[2].textContent = updatedCategory;
      cells[3].textContent = updatedDescription;

      // Update the actions column with Delete and Update buttons
      cells[4].innerHTML = '<form method="POST" style="display:inline;"><input type="hidden" name="deleteIndex" value="' + index + '"><button class="btn-delete" onclick="return confirm(\'Are you sure you want to delete this expense?\')">Delete</button></form> <button class="btn-update" onclick="editExpense(this, ' + index + ')">Update</button>';
    }
  </script>
</body>
</html>
