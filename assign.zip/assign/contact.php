<?php
require 'config.php';

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
            <div class="contactform">
                <form>
                    <h1>Contact me for work/general Enquiries</h1>
                    <div class="mb-3">
                      <label for="clientemail" class="form-label">Name</label>
                      <input type="email" class="form-control" id="clientemail" aria-describedby="emailHelp">
                    </div>
                    <div class="mb-3">
                        <label for="clientemail" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="clientemail" aria-describedby="emailHelp">
                        <br>
                        <div id="emailHelp" class="form-text">We'll never share your email and phone with anyone else.</div>
                      </div>
                    <div class="mb-3">
                      <label for="clientPhone" class="form-label">Phone</label>
                      <input type="Phone" class="form-control" id="clientPhone">
                    </div>
                    <div class="mb-3">
                        <label for="clientemail" class="form-label">Enquiry</label>
                        <input type="email" class="form-control" id="clientemail" aria-describedby="emailHelp">
                      </div>
                    <div class="mb-3 " id="form-check">
                      <input type="checkbox" class="form-check-input" id="isclient">
                      <label class="form-check-label" for="isclient">I want you to work on a project with me.</label>
                    </div>
                    <button type="submit" class="btn btn-sm">Submit</button>  
                </form>

            </div>
            <div class="contactpic">
                    <img src="contact.jpg" alt="contact pic">
                    
                </div>
        </div>
    </div>
</body>

</html>