<?php
// Establishing the database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user";

$conn = mysqli_connect($servername, $username, $password,$dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Handling the form submission
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password1'];
$confirmpassword = $_POST['password2'];

$query = "INSERT INTO info (name, email, password,confirmpassword) VALUES ('$name', '$email', '$password',$confirmpassword)";
$result = mysqli_query($conn, $query);

if ($result) {
    if (mysqli_affected_rows($conn) > 0) {
        echo "Form submitted successfully!";
    } else {
        echo "No rows were affected by the query.";
    }
} else {
    echo "Error: " . mysqli_error($conn);
}


// Closing the database connection
mysqli_close($conn);
?>
