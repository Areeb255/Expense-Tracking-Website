<?php
session_start();

// Retrieve expenses from session
function getExpensesFromSession() {
  return isset($_SESSION['expenses']) ? $_SESSION['expenses'] : [];
}

// Save expenses to session
function saveExpensesToSession($expenses) {
  $_SESSION['expenses'] = $expenses;
}

// Array to store expenses
$expenses = getExpensesFromSession();

// Add new expense to the expenses array
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $date = $_POST['date'];
  $amount = $_POST['amount'];
  $category = $_POST['category'];
  $description = $_POST['description'];

  // Create an array for the new expense
  $newExpense = array(
    'date' => $date,
    'amount' => $amount,
    'category' => $category,
    'description' => $description
  );

  // Add the new expense to the expenses array
  $expenses[] = $newExpense;

  // Save the updated expenses array to session
  saveExpensesToSession($expenses);

  // Redirect to the report page
  header('Location: report.php');
  exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Expense Tracker</title>
  <style>
    table {
      border-collapse: collapse;
      width: 100%;
    }
    th, td {
      padding: 8px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }
    form {
      margin-bottom: 20px;
    }
    input[type="text"], input[type="number"], select {
      padding: 5px;
      width: 200px;
    }
    input[type="submit"] {
      padding: 5px 10px;
      background-color: #4CAF50;
      color: white;
      border: none;
      cursor: pointer;
    }
    #search {
      margin-top: 20px;
    }
  </style>
</head>
<body>
  <h2>Expense Tracker</h2>

  <form id="expenseForm" method="POST">
    <label for="date">Date:</label>
    <input type="date" id="date" name="date" required><br>

    <label for="amount">Amount:</label>
    <input type="number" id="amount" name="amount" required><br>

    <label for="category">Category:</label>
    <select id="category" name="category" required>
      <option value="food">Food</option>
      <option value="transportation">Transportation</option>
      <option value="housing">Housing</option>
      <option value="entertainment">Entertainment</option>
      <option value="other">Other</option>
    </select><br>

    <label for="description">Description:</label>
    <input type="text" id="description" name="description" required><br>

    <input type="submit" value="Add Expense">
  </form>

  <input type="text" id="search" placeholder="Search by category" onkeyup="searchExpense()">

  <table id="expenseTable">
    <thead>
      <tr>
        <th>Date</th>
        <th>Amount</th>
        <th>Category</th>
        <th>Description</th>
      </tr>
    </thead>
    <tbody id="expenseTableBody">
      <?php foreach ($expenses as $expense): ?>
      <tr>
        <td><?php echo $expense['date']; ?></td>
        <td><?php echo $expense['amount']; ?></td>
        <td><?php echo $expense['category']; ?></td>
        <td><?php echo $expense['description']; ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <script>
    // Function to search expenses by category
    function searchExpense() {
      var input = document.getElementById('search').value.toLowerCase();
      var filteredExpenses = <?php echo json_encode($expenses); ?>.filter(function(expense) {
        return expense.category.toLowerCase().indexOf(input) > -1;
      });

      // Clear the expense table
      var tbody = document.getElementById('expenseTableBody');
      tbody.innerHTML = '';

      // Add filtered expenses to the table
      filteredExpenses.forEach(function(expense) {
        var row = tbody.insertRow();

        var dateCell = row.insertCell(0);
        dateCell.innerHTML = expense.date;

        var amountCell = row.insertCell(1);
        amountCell.innerHTML = expense.amount;

        var categoryCell = row.insertCell(2);
        categoryCell.innerHTML = expense.category;

        var descriptionCell = row.insertCell(3);
        descriptionCell.innerHTML = expense.description;
      });
    }
  </script>
</body>
</html>
